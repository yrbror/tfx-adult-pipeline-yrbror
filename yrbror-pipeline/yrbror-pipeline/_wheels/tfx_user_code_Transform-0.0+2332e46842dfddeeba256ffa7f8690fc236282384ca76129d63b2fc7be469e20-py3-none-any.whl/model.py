import tensorflow as tf
from tensorflow import keras
import tensorflow_transform as tft

NUMERIC_LOGICAL = ["age","fnlwgt","education_num","capital_gain","capital_loss","hours_per_week"]
CATEGORICAL_LOGICAL = ["workclass","education","marital_status","occupation","relationship","race","sex","native_country"]
LABEL_LOGICAL = "income"
NUM_OOV = 1
def _xf(n): return f"{n}_xf"

def build_keras_model(tft_out):
  inputs, feats = {}, []
  for n in NUMERIC_LOGICAL:
    k=_xf(n); i=keras.Input(shape=(), name=k, dtype=tf.float32); inputs[k]=i; feats.append(i)
  for n in CATEGORICAL_LOGICAL:
    k=_xf(n); vocab=tft_out.vocabulary_size_by_name(n)+NUM_OOV
    i=keras.Input(shape=(), name=k, dtype=tf.int64); inputs[k]=i
    emb=keras.layers.Embedding(vocab, min(50, max(8, vocab//2)))(tf.cast(i, tf.int32))
    feats.append(keras.layers.Reshape((-1,))(emb))
  x=keras.layers.Concatenate()(feats)
  x=keras.layers.Dense(256, activation="relu")(x); x=keras.layers.Dropout(0.2)(x)
  x=keras.layers.Dense(128, activation="relu")(x); x=keras.layers.Dropout(0.2)(x)
  out=keras.layers.Dense(1, activation="sigmoid")(x)
  m=keras.Model(inputs, out)
  m.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy", keras.metrics.AUC(name="auc")])
  return m

def run_fn(fn_args):
  tft_out=tft.TFTransformOutput(fn_args.transform_output)
  model=build_keras_model(tft_out)
  spec=tft_out.transformed_feature_spec()
  def _ds(files,batch=256,shuffle=True):
    return tf.data.experimental.make_batched_features_dataset(
      file_pattern=files, batch_size=batch, features=spec,
      reader=tf.data.TFRecordDataset, label_key=_xf(LABEL_LOGICAL), shuffle=shuffle)
  train=_ds(fn_args.train_files, shuffle=True)
  eval=_ds(fn_args.eval_files, shuffle=False)
  cb=[tf.keras.callbacks.EarlyStopping(patience=3, restore_best_weights=True)]
  model.fit(train, validation_data=eval, epochs=20, callbacks=cb)
  model.save(fn_args.serving_model_dir)
