import tensorflow as tf
import tensorflow_transform as tft

# Kolom target (label)
LABEL_KEY = "income"

# Kolom numerik (sesuai nama di adult.csv)
NUMERIC_FEATURE_KEYS = [
    "age",
    "fnlwgt",
    "education-num",   # <- diperbaiki dari "educational-num"
    "capital-gain",
    "capital-loss",
    "hours-per-week",
]

# Kolom kategorikal (sesuai nama di adult.csv)
CATEGORICAL_FEATURE_KEYS = [
    "workclass",
    "education",
    "marital-status",
    "occupation",
    "relationship",
    "race",
    "sex",             # <- diganti dari "gender"
    "native-country",
]

def _xf(name: str) -> str:
    """Nama fitur hasil transform (suffix _xf)."""
    return f"{name}_xf"

# ===== Helper untuk handle missing value =====

def _dense_float(x):
    """Cast ke float32 dan ganti NaN jadi 0."""
    x = tf.cast(x, tf.float32)
    x = tf.where(tf.math.is_nan(x), tf.zeros_like(x), x)
    return x

def _dense_string(x):
    """Cast ke string, strip spasi, ganti '?' / kosong jadi 'unknown'."""
    x = tf.cast(x, tf.string)
    x = tf.strings.strip(x)
    # treat '?' dan '' sebagai missing
    is_missing = tf.logical_or(tf.equal(x, ""), tf.equal(x, "?"))
    x = tf.where(is_missing, tf.constant("unknown", dtype=tf.string), x)
    return x

# ===== Main preprocessing_fn =====

def preprocessing_fn(inputs):
    outputs = {}

    # 1) Fitur numerik: imputasi + z-score
    for name in NUMERIC_FEATURE_KEYS:
        x = _dense_float(inputs[name])
        x = tft.scale_to_z_score(x)
        outputs[_xf(name)] = x

    # 2) Fitur kategorikal: imputasi + vocab -> ID
    for name in CATEGORICAL_FEATURE_KEYS:
        x = _dense_string(inputs[name])
        ids = tft.compute_and_apply_vocabulary(
            x,
            num_oov_buckets=1,
            vocab_filename=name,  # nama file vocab di TransformGraph
        )
        outputs[_xf(name)] = ids

    # 3) Label: " <=50K"/" >50K" -> 0/1
    label = _dense_string(inputs[LABEL_KEY])
    # strip spasi dulu biar aman
    label = tf.strings.strip(label)
    label_int = tf.cast(tf.equal(label, ">50K"), tf.int64)
    outputs[LABEL_KEY] = label_int

    return outputs