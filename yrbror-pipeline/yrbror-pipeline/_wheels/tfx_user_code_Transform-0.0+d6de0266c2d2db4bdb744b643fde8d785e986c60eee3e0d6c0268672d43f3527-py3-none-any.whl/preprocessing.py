import tensorflow as tf
import tensorflow_transform as tft

NUMERIC_LOGICAL = ["age","fnlwgt","education_num","capital_gain","capital_loss","hours_per_week"]
CATEGORICAL_LOGICAL = ["workclass","education","marital_status","occupation","relationship","race","sex","native_country"]
LABEL_LOGICAL = "income"
NUM_OOV = 1
def _xf(n): return f"{n}_xf"

ALIASES = {
  "education_num":["education_num","education-num","educational-num","education num"],
  "capital_gain":["capital_gain","capital-gain","capital gain"],
  "capital_loss":["capital_loss","capital-loss","capital loss"],
  "hours_per_week":["hours_per_week","hours-per-week","hours per week"],
  "native_country":["native_country","native-country","native country"],
  "marital_status":["marital_status","marital-status","marital status"],
  "sex":["sex","gender"],
  "age":["age"], "fnlwgt":["fnlwgt"], "education":["education"],
  "occupation":["occupation"], "relationship":["relationship"], "race":["race"],
  LABEL_LOGICAL:["income","class","target"],
}

def _pick(inputs, logical):
  for c in ALIASES.get(logical, [logical]):
    if c in inputs:
      return tf.squeeze(inputs[c], axis=1)
  norm = logical.replace("_","").lower()
  for k in inputs:
    kk = k.replace("_","").replace("-","").replace(" ","").lower()
    if kk == norm:
      return tf.squeeze(inputs[k], axis=1)
  raise KeyError(f"Missing column for {logical}. Available: {list(inputs.keys())[:12]} ...")

def _num(x):
  x = tf.cast(x, tf.float32)
  return tf.where(tf.math.is_nan(x), tf.zeros_like(x), x)

def _cat(s):
  s = tf.strings.strip(tf.strings.lower(tf.as_string(s)))
  return tf.where(tf.equal(s,""), tf.constant("unknown"), s)

def preprocessing_fn(inputs):
  outputs = {}
  for n in NUMERIC_LOGICAL:
    x = _num(_pick(inputs, n))
    outputs[_xf(n)] = tft.scale_to_z_score(x)
  for n in CATEGORICAL_LOGICAL:
    idx = tft.compute_and_apply_vocabulary(_cat(_pick(inputs, n)), num_oov_buckets=NUM_OOV, vocab_filename=n)
    outputs[_xf(n)] = idx
  y = tf.strings.lower(tf.strings.strip(tf.as_string(_pick(inputs, LABEL_LOGICAL))))
  outputs[_xf(LABEL_LOGICAL)] = tf.cast(tf.equal(y, ">50k"), tf.int64)
  return outputs
