import tensorflow as tf
import tensorflow_transform as tft

# Kolom target
LABEL_KEY = "income"

# Fitur numerik di adult.csv
NUMERIC_FEATURE_KEYS = [
    "age",
    "fnlwgt",
    "educational-num",
    "capital-gain",
    "capital-loss",
    "hours-per-week",
]

# Fitur kategorikal di adult.csv
CATEGORICAL_FEATURE_KEYS = [
    "workclass",
    "education",
    "marital-status",
    "occupation",
    "relationship",
    "race",
    "gender",
    "native-country",
]

def _xf(name: str) -> str:
    """Kasih suffix _xf biar beda sama nama asli."""
    return f"{name}_xf"

def _dense_float(x):
    x = tf.cast(x, tf.float32)
    x = tft.fill_in_missing(x, default_value=0.0)
    return x

def _dense_string(x):
    x = tf.cast(x, tf.string)
    x = tft.fill_in_missing(x, default_value="")
    return x

def preprocessing_fn(inputs):
    """Preprocessing utama untuk komponen Transform."""
    outputs = {}

    # 1) Numeric: imputasi + z-score
    for name in NUMERIC_FEATURE_KEYS:
        x = _dense_float(inputs[name])
        x = tft.scale_to_z_score(x)
        outputs[_xf(name)] = x

    # 2) Categorical: imputasi + vocabulary → id int
    for name in CATEGORICAL_FEATURE_KEYS:
        x = _dense_string(inputs[name])
        ids = tft.compute_and_apply_vocabulary(
            x,
            num_oov_buckets=1,
            vocab_filename=name,
        )
        outputs[_xf(name)] = ids

    # 3) Label: convert ke 0/1 (<=50K → 0, >50K → 1)
    label = _dense_string(inputs[LABEL_KEY])
    label_int = tf.cast(tf.equal(label, ">50K"), tf.int64)
    outputs[LABEL_KEY] = label_int

    return outputs