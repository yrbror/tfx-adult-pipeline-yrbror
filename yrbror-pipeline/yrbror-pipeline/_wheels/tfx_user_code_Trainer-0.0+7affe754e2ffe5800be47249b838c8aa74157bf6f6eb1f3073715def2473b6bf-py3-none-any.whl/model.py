import tensorflow as tf
import tensorflow_transform as tft

# =======================
# Konfigurasi fitur
# =======================

LABEL_KEY = "income"  # label setelah Transform: 0 / 1

NUMERIC_FEATURE_KEYS = [
    "age",
    "fnlwgt",
    "educational-num",
    "capital-gain",
    "capital-loss",
    "hours-per-week",
]

CATEGORICAL_FEATURE_KEYS = [
    "workclass",
    "education",
    "marital-status",
    "occupation",
    "relationship",
    "race",
    "gender",
    "native-country",
]


def _xf(name: str) -> str:
    """Nama fitur setelah Transform."""
    return f"{name}_xf"


# =======================
# Bangun Keras model
# =======================

def _build_keras_model(tf_transform_output: tft.TFTransformOutput) -> tf.keras.Model:
    """Bangun model dari fitur yang sudah di-transform."""
    inputs = {}
    encoded_feats = []

    # Numeric inputs (float32)
    for name in NUMERIC_FEATURE_KEYS:
        t_name = _xf(name)
        inp = tf.keras.Input(shape=(1,), name=t_name, dtype=tf.float32)
        inputs[t_name] = inp
        encoded_feats.append(inp)

    # Categorical inputs (int64 -> embedding)
    for name in CATEGORICAL_FEATURE_KEYS:
        t_name = _xf(name)
        inp = tf.keras.Input(shape=(1,), name=t_name, dtype=tf.int64)
        inputs[t_name] = inp

        # ukuran vocab dari Transform
        vocab_size = tf_transform_output.vocabulary_size_by_name(name) + 1
        emb_dim = min(50, max(8, vocab_size // 2))

        emb = tf.keras.layers.Embedding(vocab_size, emb_dim)(
            tf.cast(inp, tf.int32)
        )
        emb = tf.keras.layers.Reshape((emb_dim,))(emb)
        encoded_feats.append(emb)

    # Gabungkan semua fitur
    x = tf.keras.layers.Concatenate()(encoded_feats)
    x = tf.keras.layers.Dense(64, activation="relu")(x)
    x = tf.keras.layers.Dense(32, activation="relu")(x)
    x = tf.keras.layers.Dropout(0.2)(x)
    outputs = tf.keras.layers.Dense(1, activation="sigmoid")(x)

    model = tf.keras.Model(inputs=inputs, outputs=outputs)

    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3),
        loss="binary_crossentropy",
        metrics=[tf.keras.metrics.BinaryAccuracy(name="accuracy")],
    )

    return model


# =======================
# Input pipeline
# =======================

def _input_fn(file_pattern, tf_transform_output, batch_size=256):
    """Buat tf.data.Dataset dari TFRecord yang sudah di-transform."""
    transformed_feature_spec = tf_transform_output.transformed_feature_spec().copy()

    dataset = tf.data.experimental.make_batched_features_dataset(
        file_pattern=file_pattern,
        batch_size=batch_size,
        features=transformed_feature_spec,
        label_key=LABEL_KEY,      # label sudah bernama "income" di preprocessing_fn
        reader=tf.data.TFRecordDataset,   # TANPA compression_type → biar nggak DataLoss
    )
    return dataset


# =======================
# Fungsi utama untuk TFX Trainer
# =======================

def run_fn(fn_args):
    """Dipanggil oleh TFX Trainer."""

    tf_transform_output = tft.TFTransformOutput(fn_args.transform_output)

    train_dataset = _input_fn(
        fn_args.train_files,
        tf_transform_output,
        batch_size=256,
    )

    eval_dataset = _input_fn(
        fn_args.eval_files,
        tf_transform_output,
        batch_size=256,
    )

    model = _build_keras_model(tf_transform_output)

    model.fit(
        train_dataset,
        steps_per_epoch=fn_args.train_steps,
        validation_data=eval_dataset,
        validation_steps=fn_args.eval_steps,
    )

    # Simpan model ke path yang diberikan TFX
    model.save(fn_args.serving_model_dir, save_format="tf")