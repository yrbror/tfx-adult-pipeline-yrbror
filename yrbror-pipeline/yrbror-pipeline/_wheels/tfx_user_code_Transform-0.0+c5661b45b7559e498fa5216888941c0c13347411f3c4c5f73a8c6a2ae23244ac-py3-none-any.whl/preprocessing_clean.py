import tensorflow as tf
import tensorflow_transform as tft

# Kolom target
LABEL_KEY = "income"

# Numeric columns
NUMERIC_FEATURE_KEYS = [
    "age",
    "fnlwgt",
    "educational-num",
    "capital-gain",
    "capital-loss",
    "hours-per-week",
]

# Categorical columns
CATEGORICAL_FEATURE_KEYS = [
    "workclass",
    "education",
    "marital-status",
    "occupation",
    "relationship",
    "race",
    "gender",
    "native-country",
]

def _xf(name: str) -> str:
    return f"{name}_xf"

# === REPLACEMENT for removed fill_in_missing() ===
def _dense_float(x):
    x = tf.cast(x, tf.float32)
    # replace missing with 0
    x = tf.where(tf.math.is_nan(x), tf.zeros_like(x), x)
    return x

def _dense_string(x):
    x = tf.cast(x, tf.string)
    # empty string → "unknown"
    x = tf.where(tf.equal(x, ""), tf.constant("unknown", dtype=tf.string), x)
    return x

def preprocessing_fn(inputs):
    outputs = {}

    # Numeric features: impute + zscore
    for name in NUMERIC_FEATURE_KEYS:
        x = _dense_float(inputs[name])
        x = tft.scale_to_z_score(x)
        outputs[_xf(name)] = x

    # Categorical features: impute + vocab → IDs
    for name in CATEGORICAL_FEATURE_KEYS:
        x = _dense_string(inputs[name])
        ids = tft.compute_and_apply_vocabulary(
            x,
            num_oov_buckets=1,
            vocab_filename=name
        )
        outputs[_xf(name)] = ids

    # Label transform: ">50K" → 1, lainnya → 0
    label = _dense_string(inputs[LABEL_KEY])
    label_int = tf.cast(tf.equal(label, ">50K"), tf.int64)
    outputs[LABEL_KEY] = label_int

    return outputs